<!DOCTYPE html>
<html>
<head>
  <title>📱 ดูภาพจากคอม</title>
  <meta http-equiv="refresh" content="1"> <!-- รีโหลดภาพทุก 1 วิ -->
  <style> img { max-width: 100%; } </style>
</head>
<body>
  <h2>📲 ภาพเรียลไทม์</h2>
  <img src="stream.jpg?<?php echo time(); ?>" alt="Live Stream">
</body>
</html>
